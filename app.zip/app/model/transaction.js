module.exports = (sequelize, Sequelize) => {
	const Transaction = sequelize.define('transaction', {
	  accountId: {
		type: Sequelize.STRING
	  },
	  amount: {
		type: Sequelize.STRING
	  },
	  remark: {
		  type: Sequelize.STRING
      },
      paymentType: {
        type: Sequelize.STRING
    },
	});	
	return Transaction;
}