const env = require('./env.js');
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const sequelize = new Sequelize(env.database, env.username, env.password, 
  {
  host: env.host,
  dialect: env.dialect,
  operatorsAliases: false,
  pool: {
    max: 10,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
})

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;
//Models/tables
db.account = require('../model/account.js')(sequelize, Sequelize);
db.transaction = require('../model/transaction.js')(sequelize, Sequelize);

module.exports = db;