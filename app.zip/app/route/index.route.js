module.exports = (app) => {
    require('./account.route.js')(app);  
    require('./transaction.route.js')(app);  
}
