module.exports = function(app) {
 
    const accounts = require('../controller/account.controller.js');
 
    // Create a new Account
    app.post('/api/accounts', accounts.create);
 
    // Retrieve all Account
    app.get('/api/accounts', accounts.findAll);
 
    // Retrieve a single Account by Id
    app.get('/api/accounts/:accountId', accounts.findById);
 
    // Update a Account with Id
    app.put('/api/accounts/:accountId', accounts.update);
 
    // Delete a Account with Id
    app.delete('/api/accounts/:accountId', accounts.delete);
}