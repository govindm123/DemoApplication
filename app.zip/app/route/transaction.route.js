module.exports = function(app) {
 
    const transactions = require('../controller/transaction.controller.js');
 
    // Create a new transactions
    app.post('/api/transactions', transactions.create);
 
    // Retrieve all transactions
    app.get('/api/transactions', transactions.findAll);
 
    // Retrieve a single transactions by Id
    app.get('/api/transactions/:accountId', transactions.findById);

    // Delete a transactions with Id
    app.delete('/api/transactions/:accountId', transactions.delete);
}